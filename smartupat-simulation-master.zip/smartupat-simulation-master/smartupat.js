let strip; // need to be global

$(document).ready(() => {
  let lightGridSize; // Size of the smartupat
  let inputPixelsRGB;

  // The url of the file we want to read from; If put at the same level as 'smartupat.html'
  $.get('/files/emoji.txt').then((res) => {
    // console.log(typeof res) => the response is of string type
    const inputGridImage = res.split('\n'); // the last two elements are '0' and 'EOL', so we pop them
    inputGridImage.pop();
    inputGridImage.pop();
    console.log('Input grid size', inputGridImage.length);

    lightGridSize = Math.round(Math.sqrt(inputGridImage.length));


    inputPixelsRGB = inputGridImage.map(rgb => [
      (rgb >> 16) & 0xFF, // red
      (rgb >> 8) & 0xFF, // green - this is similar to (rgb/256) % 256
      (rgb) & 0xFF, // blue - this is similar to (rgb % 256)
    ]);
  })
    .then(() => {
      console.log('lightGridSize:', lightGridSize);
      for (let i = 0; i < lightGridSize; i++) {
        const ind = i * lightGridSize;
        // console.log('ind::', ind);
        $('.ledstrip-container .ledstrip').append(`<div class='ledstrip-${i}'></div>`);
        const container = $(`.ledstrip-container .ledstrip-${i}`)[0]; // this will select the container for housing the LED lights

        const colorsArr = inputPixelsRGB.slice(ind, ind + lightGridSize);
        strip = LEDstrip(container, lightGridSize);
        strip.setcolors(colorsArr.reverse());
        // strip.buffer = colorsArr
        strip.send();
      }
    });

  $('#diffuser').change((e) => {
    $('.ledstrip').toggleClass('diffuse');
  });
});
