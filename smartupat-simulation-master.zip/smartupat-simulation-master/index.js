var strip, animation; // need to be global

$(document).ready(function () {
    // I need a way to come up with 24x24 and 36x36 square matrix for LED
    var lightGridSize = 16; //total lights
    for(var i = 0; i < lightGridSize; i++) {
        $('.ledstrip-container .ledstrip').append(`<div class='ledstrip-${i}'></div>`);
        var container = $(`.ledstrip-container .ledstrip-${i}`)[0]; //this will select the container for housing the LED lights
        strip = LEDstrip(container, lightGridSize);
        driver = new ColorWave(strip);
        driver.init();
        animation = driver.animate.bind(driver)();
    }

    var lightGridSize = 20; //total lights
    for(var i = 0; i < lightGridSize; i++) {
        $('.ledstrip-container-2 .ledstrip').append(`<div class='ledstrip-${i}'></div>`);
        var container = $(`.ledstrip-container-2 .ledstrip-${i}`)[0]; //this will select the container for housing the LED lights
        strip = LEDstrip(container, lightGridSize);
        driver = new ColorWave(strip);
        driver.init();
        animation = driver.animate.bind(driver)();
    }
    
    $('#diffuser').change(function (e) {
        $('.ledstrip').toggleClass('diffuse');
    });

    $('#animselect').change(function (e) {
        var newanim = $(e.target).val();
        console.log('change! ' + newanim);
        animation = cancelAnimationFrame(animation);
        switch (newanim) {
            case 'torture':
                driver = new water_torture(strip);
                break;
            case 'wave':
                driver = new ColorWave(strip);
                break;
            case 'chasers':
                driver = new Chasers(strip);
                break;
            case 'larson':
                driver = new Larson(strip);
                break;
            case 'bouncingballs':
                driver = new BouncingBalls(strip);
                break;
            case 'lightning':
                driver = new Lightning(strip);
                break;
            case 'twinklesparkle':
                driver = new TwinkleSparkle(strip);
                break;
            case 'fire':
                driver = new Fire(strip);
                break;
            case 'eyeblink':
                driver = new Eyeblinks(strip);
                break;
            /*
                case 'cycle': 
                  cycle.color_cycle();
                  console.log('torture ' + animation);
                  break;
                case 'flares':        
                  driver = new flare();
                  break;
            */
            case 'stop':
                animation = cancelAnimationFrame(animation);
                return;
                break;
        } // /switch
        driver.init();
        animation = driver.animate();
    });
});